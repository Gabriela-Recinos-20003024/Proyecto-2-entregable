/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pf.controlador;

import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ChoiceBox;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import pf.Modelo.Etapa;
import pf.util.HibernateUtil;

/**
 *
 * @author tavop
 */
public class asistenteetapa {
    SessionFactory sesion;
    Session session;
    Transaction tx;
    
    
public void IniciarS(){
        try {
        sesion = HibernateUtil.getSessionFactory();
        session = sesion.openSession();
        tx = session.beginTransaction();
        }catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }
    

    public ChoiceBox ListaEtapa(){
        ChoiceBox cb = new ChoiceBox();
        List<Etapa> ListaEtapa = new ArrayList<Etapa>();

    IniciarS();
    List<Etapa> Etapass = session.createQuery("from Etapa").list();
    tx.commit();
    for (Etapa Etapaadd : Etapass) {
        ListaEtapa.add(Etapaadd);
        cb.getItems().add(Etapaadd.getNombre());
        }
    session.close();
    return cb;
    }
    
    public List ListaEtapa2(){
        ChoiceBox cb = new ChoiceBox();
        List<Etapa> ListaEtapa = new ArrayList<Etapa>();

    IniciarS();
    List<Etapa> Etapass = session.createQuery("from Etapa").list();
    tx.commit();
    for (Etapa Etapaadd : Etapass) {
        ListaEtapa.add(Etapaadd);
        cb.getItems().add(Etapaadd.getNombre());
        }
    session.close();
    return ListaEtapa;
    }
}
