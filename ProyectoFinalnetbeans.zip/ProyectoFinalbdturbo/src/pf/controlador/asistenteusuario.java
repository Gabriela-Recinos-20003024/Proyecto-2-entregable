/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pf.controlador;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import pf.Modelo.Usuario;
import pf.util.HibernateUtil;

/**
 *
 * @author tavop
 */
public class asistenteusuario {
    SessionFactory sesion;
    Session session;
    Transaction tx;
    
public void IniciarS(){
        try {
        sesion = HibernateUtil.getSessionFactory();
        session = sesion.openSession();
        tx = session.beginTransaction();
        }catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public String Verificar(String Usuariou, String Usuariop){
        String x = "";
        IniciarS();
        Usuario user = new Usuario();
        user = (Usuario)session.get(Usuario.class,Usuariou);
        if(session.get(Usuario.class,Usuariou) == null){
        x = "incorrecto";}else{
            if(user.getContrasena().equals(Usuariop)){x = "correcto";}
                else{x = "incorrecto";}
        }
        tx.commit();
        session.close();
        return x;
    }
}
