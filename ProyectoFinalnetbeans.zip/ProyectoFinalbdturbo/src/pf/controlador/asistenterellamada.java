/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pf.controlador;

import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import pf.Modelo.Rellamada;
import pf.util.HibernateUtil;

/**
 *
 * @author tavop
 */
public class asistenterellamada {

    SessionFactory sesion;
    Session session;
    Transaction tx;
    
public void IniciarS(){
        try {
        sesion = HibernateUtil.getSessionFactory();
        session = sesion.openSession();
        tx = session.beginTransaction();
        }catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public String VerificarQ(int NLLAMADA){
        String x = "";
        IniciarS();
        Rellamada llamada = new Rellamada();
        llamada = (Rellamada)session.get(Rellamada.class,NLLAMADA);
        if(session.get(Rellamada.class,NLLAMADA) == null){
        x = "NoExiste";}else{x = "Existe";}
        tx.commit();
        session.close();
        return x;
    }
    
    public void crearReLlamada(Object cl,int x){
        if(VerificarQ(x).equals("Existe")){}else{;
        IniciarS();
        session.save(cl);
        tx.commit();
        session.close();
        System.out.println("save");
        }
    }
    
    public void EliminarReLlamada(int x){
        Rellamada subRellamada = new Rellamada();
        IniciarS();
        subRellamada = (Rellamada)session.get(Rellamada.class,x);
        session.delete(subRellamada);
        tx.commit();
        session.close();
        System.out.println("Eliminado");
    }
    
    public ObservableList<Rellamada> tablaRellamada(){
        List<Rellamada> ListaRellamada = new ArrayList<Rellamada>();

    IniciarS();
    List<Rellamada> Rellamadass = session.createQuery("from Rellamada").list();
    tx.commit();
    for (Rellamada Rellamadadd : Rellamadass) {
        ListaRellamada.add(Rellamadadd);
        }
    ObservableList<Rellamada> obRellamada = FXCollections.observableList(ListaRellamada);
    session.close();
    return obRellamada;
    }
    

}

