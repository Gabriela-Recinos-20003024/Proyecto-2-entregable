/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pf.controlador;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Side;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.DatePicker;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import pf.util.HibernateUtil;

/**
 *
 * @author tavop
 */
public class asistentegrafica {
        SessionFactory sesion;
    Session session;
    Transaction tx;
    
    public void IniciarS(){
        try {
        sesion = HibernateUtil.getSessionFactory();
        session = sesion.openSession();
        tx = session.beginTransaction();
        }catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
public BarChart resultados(String x){
    int x1 = 0;int x2 = 0;int x3 = 0;int x4 = 0;int x5 = 0;int x6 = 0;
        IniciarS();
        Query  pen = session.createQuery("select count(*) FROM Queja WHERE Idetapa = 0 AND fecha =  '"+x+"'");
        tx.commit();
        Iterator count1 = pen.iterate();
        x1 = Integer.parseInt(count1.next().toString().trim());
        session.close();
        IniciarS();
        Query  tge = session.createQuery("select count(*) FROM Queja WHERE Idetapa = 1 AND fecha =  '"+x+"'");
        tx.commit();
        Iterator count2 = tge.iterate();
        x2 = Integer.parseInt(count2.next().toString().trim());
        session.close();
        IniciarS();
        Query  cge = session.createQuery("select count(*) FROM Queja WHERE Idetapa = 2 AND fecha =  '"+x+"'");
        tx.commit();
        Iterator count3 = cge.iterate();
        x3 = Integer.parseInt(count3.next().toString().trim());
        session.close();
        IniciarS();
        Query  cve = session.createQuery("select count(*) FROM Queja WHERE Idetapa = 3 AND fecha =  '"+x+"'");
        tx.commit();
        Iterator count4 = cve.iterate();
        x4 = Integer.parseInt(count4.next().toString().trim());
        session.close();
        IniciarS();
        Query  prc = session.createQuery("select count(*) FROM Queja WHERE Idetapa = 4 AND fecha =  '"+x+"'");
        tx.commit();
        Iterator count5 = prc.iterate();
        x5 = Integer.parseInt(count5.next().toString().trim());
        session.close();
        IniciarS();
        Query  tlq = session.createQuery("select count(*) FROM Queja WHERE Idetapa = 5 AND fecha =  '"+x+"'");
        tx.commit();
        Iterator count6 = tlq.iterate();
        x6 = Integer.parseInt(count6.next().toString().trim());
        session.close();
        


        //grafica
        CategoryAxis ejex = new CategoryAxis();
        ejex.setLabel("ETAPA");
        NumberAxis ejey = new NumberAxis();
        ejey.setLabel("Quejas");
        BarChart Grafico = new BarChart(ejex,ejey);
        Grafico.setTitle("Quejas por etapa fecha "+ x );
        Grafico.setMaxSize(350,300);
        XYChart.Series<String,Number> Pendientes = new XYChart.Series<>();
        Pendientes.setName("Pendientes");
        Pendientes.getData().add(new XYChart.Data<>("Pendientes", x1));
        XYChart.Series<String,Number> TGE = new XYChart.Series<>();
        TGE.setName("TGE");
        TGE.getData().add(new XYChart.Data<>("TGE", x2));
        XYChart.Series<String,Number> CGE = new XYChart.Series<>();
        CGE.setName("CGE");
        CGE.getData().add(new XYChart.Data<>("CGE", x3));
        XYChart.Series<String,Number> CVE = new XYChart.Series<>();
        CVE.setName("CVE");
        CVE.getData().add(new XYChart.Data<>("CVE", x4));
        XYChart.Series<String,Number> PRC = new XYChart.Series<>();
        PRC.setName("PRC");
        PRC.getData().add(new XYChart.Data<>("PRC", x5));
        XYChart.Series<String,Number> TLQ = new XYChart.Series<>();
        TLQ.setName("TLQ");
        TLQ.getData().add(new XYChart.Data<>("TLQ", x6));
        
        ObservableList<XYChart.Series<String, Number>> data = FXCollections.observableArrayList();
        data.addAll(Pendientes,TGE,CGE,CVE,PRC,TLQ);
        Grafico.setData(data);
        
        
        return Grafico;
    }
    public int[] resultadosAA(){
        int [] Resu = new int[10];
        int x1 = 0;int x2 = 0;int x3 = 0;int x4 = 0;int x5 = 0;int x6 = 0;int x7 = 0;int x8 = 0;
        //******
        IniciarS();
        Query  pen = session.createQuery("select count(*) FROM Queja WHERE Idetapa = 0");
        tx.commit();
        Iterator count1 = pen.iterate();
        x1 = Integer.parseInt(count1.next().toString().trim());
        session.close();
        IniciarS();
        Query  tge = session.createQuery("select count(*) FROM Queja WHERE Idetapa = 1");
        tx.commit();
        Iterator count2 = tge.iterate();
        x2 = Integer.parseInt(count2.next().toString().trim());
        session.close();
        IniciarS();
        Query  cge = session.createQuery("select count(*) FROM Queja WHERE Idetapa = 2");
        tx.commit();
        Iterator count3 = cge.iterate();
        x3 = Integer.parseInt(count3.next().toString().trim());
        session.close();
        IniciarS();
        Query  cve = session.createQuery("select count(*) FROM Queja WHERE Idetapa = 3");
        tx.commit();
        Iterator count4 = cve.iterate();
        x4 = Integer.parseInt(count4.next().toString().trim());
        session.close();
        IniciarS();
        Query  prc = session.createQuery("select count(*) FROM Queja WHERE Idetapa = 4");
        tx.commit();
        Iterator count5 = prc.iterate();
        x5 = Integer.parseInt(count5.next().toString().trim());
        session.close();
        IniciarS();
        Query  tlq = session.createQuery("select count(*) FROM Queja WHERE Idetapa = 5");
        tx.commit();
        Iterator count6 = tlq.iterate();
        x6 = Integer.parseInt(count6.next().toString().trim());
        session.close();
        IniciarS();
        Query  llamadas = session.createQuery("select count(*) FROM Llamada");
        tx.commit();
        Iterator count7 = llamadas.iterate();
        x7 = Integer.parseInt(count7.next().toString().trim());
        session.close();
        IniciarS();
        Query  rellamadas = session.createQuery("select count(*) FROM Rellamada");
        tx.commit();
        Iterator count8 = rellamadas.iterate();
        x8 = Integer.parseInt(count8.next().toString().trim());
        session.close();
        Resu[0] = x1;
        Resu[1] = x2;
        Resu[2] = x3;
        Resu[3] = x4;
        Resu[4] = x5;
        Resu[5] = x6;
        Resu[6] = x7;
        Resu[7] = x8;
        Resu[8] = x1+x2+x3+x4+x5+x6;
        Resu[9] = x7+x8;
        
        
        return Resu;
    }
}
