/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pf.vista;

import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import pf.Modelo.Llamada;
import pf.Modelo.Queja;
import pf.Modelo.Rellamada;
import pf.controlador.asistentellamada;
import pf.controlador.asistentequeja;
import pf.controlador.asistenterellamada;

/**
 *
 * @author tavop
 */
public class tablasv {
    
    public void tablasv(){
        
    }
    public Pane TablaRellamada(){
        GridPane Form2 = new GridPane();
        TableView MostraDatos = new TableView();
        MostraDatos.setEditable(false);
        TableColumn NoCol = new TableColumn("No.");
        TableColumn FeCol = new TableColumn("Fecha");
        TableColumn ComCol = new TableColumn("Comentario");
        ComCol.setMinWidth(200);
        NoCol.setCellValueFactory(new PropertyValueFactory<>("idrellamada"));
        FeCol.setCellValueFactory(new PropertyValueFactory<>("fecha"));
        ComCol.setCellValueFactory(new PropertyValueFactory<>("comentario"));
        asistenterellamada opera = new asistenterellamada();
        ObservableList<Rellamada> data = opera.tablaRellamada();
        MostraDatos.setItems(data);
        MostraDatos.getColumns().addAll(NoCol,FeCol,ComCol);
        MostraDatos.setMaxSize(400, 250);
        MostraDatos.refresh();
        
        Form2.setPadding(new Insets(10, 10, 10, 10)); 
            Form2.setVgap(20); 
            Form2.setHgap(10);     
            Form2.add(new Label("Llamadas pendientes"), 1,0);
            Form2.add(new Separator(), 1,2);
            Form2.add(MostraDatos, 1,3);  
        
      
MostraDatos.setOnMouseClicked(new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent event) {
            if (event.getClickCount() == 2) { 
                if(MostraDatos.getSelectionModel().getSelectedItem()==null){}else{
                Rellamada Seleccion = (Rellamada) MostraDatos.getSelectionModel().getSelectedItem();
            System.out.println("Clicked on " + (Seleccion.getIdrellamada()));  
                opera.EliminarReLlamada(Seleccion.getIdrellamada());
                ObservableList<Rellamada> data = opera.tablaRellamada();
        MostraDatos.setItems(data);
            //llamar a metodo modificar;
            }}
        }
    });
        return Form2;
        }    
        
    public TableView TablaQuejas(){
        TableView MostraDatos = new TableView();
        MostraDatos.setEditable(false);
        TableColumn NoCol = new TableColumn("No.");
        TableColumn TelCol = new TableColumn("Telefono");
        TableColumn FeCol = new TableColumn("Fecha");
        TableColumn ComCol = new TableColumn("Comentario");
        ComCol.setMinWidth(200);
        NoCol.setCellValueFactory(new PropertyValueFactory<>("nqueja"));
        TelCol.setCellValueFactory(new PropertyValueFactory<>("ntelefono"));
        FeCol.setCellValueFactory(new PropertyValueFactory<>("fecha"));
        ComCol.setCellValueFactory(new PropertyValueFactory<>("comentario"));
        asistentequeja opera = new asistentequeja();
        ObservableList<Queja> data = opera.tablaQueja();
        MostraDatos.setItems(data);
        MostraDatos.getColumns().addAll(NoCol,TelCol,FeCol,ComCol);
        MostraDatos.setMaxSize(400, 100);
        MostraDatos.refresh();
        return MostraDatos;
        }

    public TableView TablaLlamadas(){
        TableView MostraDatos = new TableView();
        MostraDatos.setEditable(false);
        TableColumn NoCol = new TableColumn("ID");
        TableColumn TelCol = new TableColumn("Telefono");
        TableColumn FeCol = new TableColumn("Tecnico");
        TableColumn tarCol = new TableColumn("Trabajo");
        TableColumn fecCol = new TableColumn("Fecha");
        TableColumn ComCol = new TableColumn("Comentario");
        NoCol.setCellValueFactory(new PropertyValueFactory<>("Idllamada"));
        TelCol.setCellValueFactory(new PropertyValueFactory<>("Ntelefono"));
        FeCol.setCellValueFactory(new PropertyValueFactory<>("Ntecnico"));
        tarCol.setCellValueFactory(new PropertyValueFactory<>("Trabajo"));
        fecCol.setCellValueFactory(new PropertyValueFactory<>("Fecha"));
        ComCol.setCellValueFactory(new PropertyValueFactory<>("Comentario"));
        asistentellamada opera = new asistentellamada();
        ObservableList<Llamada> data = opera.tablallamada();
        MostraDatos.setItems(data);
        MostraDatos.getColumns().addAll(NoCol,TelCol,FeCol,fecCol,tarCol,ComCol);
        MostraDatos.setMaxSize(400, 100);
        //MostraDatos.setMinSize(500, 490);
        MostraDatos.refresh();
        return MostraDatos;
        }
    
    public Pane listatabla(){
        GridPane x = new GridPane();
        x.setPadding(new Insets(10, 10, 10, 10)); 
            x.setVgap(20); 
            x.setHgap(10);     
            x.add(new Label("Quejas Recibidas"), 1,0);
            x.add(TablaQuejas(), 1,1); 
            x.add(new Separator(), 1,2);
            x.add(new Label("Llamadas Realizadas"), 1,3);
            x.add(TablaLlamadas(), 1,4); 
        x.setLayoutX(0);x.setLayoutY(0);
        return x;
    }
}
