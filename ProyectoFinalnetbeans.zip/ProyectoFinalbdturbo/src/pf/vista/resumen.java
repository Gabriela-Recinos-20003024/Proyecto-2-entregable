/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pf.vista;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import pf.controlador.asistentegrafica;

/**
 *
 * @author tavop
 */
public class resumen {
    public Pane resumenx(){
        asistentegrafica ag = new asistentegrafica();
        int [] y = ag.resultadosAA();
        Pane x = new Pane();
        GridPane GP = new GridPane();
        GP.setPadding(new Insets(10, 10, 10, 10)); 
            GP.setVgap(2); 
            GP.setHgap(10);     
        GP.add(new Label("Resumen"), 1,0); 
        GP.add(new Separator(), 1,1); 
        GP.add(new Label("QUEJAS"), 1,2); 
        GP.add(new Label("TOTAL: "+y[8]), 2,2); 
        GP.add(new Separator(), 1,3); 
        GP.add(new Label("TGE"), 1,4); 
        GP.add(new Label("->"+y[1]), 2,4); 
        GP.add(new Label("CGE"), 1,5); 
        GP.add(new Label("->"+y[2]), 2,5); 
        GP.add(new Label("CVE"), 1,6); 
        GP.add(new Label("->"+y[3]), 2,6); 
        GP.add(new Label("PRC"), 1,7);
        GP.add(new Label("->"+y[4]), 2,7); 
        GP.add(new Label("TLQ"), 1,8); 
        GP.add(new Label("->"+y[5]), 2,8); 
        GP.add(new Label("PENDIENTES"), 1,9); 
        GP.add(new Label("->"+y[0]), 2,9); 
        GP.add(new Separator(), 1,10); 
        GP.add(new Label("Llamadas"), 1,11); 
        GP.add(new Label("TOTAL: "+y[9]), 2,11); 
        GP.add(new Separator(), 1,12); 
        GP.add(new Label("Registradas"), 1,13); 
        GP.add(new Label("->"+y[6]), 2,13); 
        GP.add(new Label("Pendientes"), 1,14); 
        GP.add(new Label("->"+y[7]), 2,14); 
        GP.add(new Separator(), 1,15); 
        GP.add(new Label("TOTAL DE TRABAJO:"), 1,16); 
        GP.add(new Label("-> "+(y[9]+y[8])), 2,16); 
        GP.setLayoutX(20);x.setLayoutY(20);
        GP.setMinSize(300,300);
        x.getChildren().add(GP);
        
        
        return x;
    }
}
