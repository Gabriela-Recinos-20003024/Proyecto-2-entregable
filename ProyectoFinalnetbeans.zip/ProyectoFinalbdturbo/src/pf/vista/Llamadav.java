/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pf.vista;

import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import pf.Modelo.Llamada;
import pf.controlador.asistentellamada;

/**
 *
 * @author tavop
 */
public class Llamadav {
    TextField t1,t2,t3,t4,t5;
    asistentellamada aq;
    ChoiceBox cb;
    /*
      this.idllamada = idllamada;
       this.ntelefono = ntelefono;
       this.ntecnico = ntecnico;
       this.trabajo = trabajo;
       this.comentario = comentario;
       this.fecha = fecha;
    */
    public Pane crearpanel(){
        Pane retorno = new Pane();
        Label te = new Label("Ingreso de Llamadas");
        te.setLayoutX(30);te.setLayoutY(30);
        GridPane GPu = new GridPane();
            GPu.setPadding(new Insets(10, 10, 10, 10)); 
            GPu.setVgap(20); 
            GPu.setHgap(30);
            GPu.add(new Label("Id. Llamada"), 1,0); 
            GPu.add(new Label("No. Telefono"), 1,1);
            GPu.add(new Label("Nombre Tecnico"), 1,2);
            GPu.add(new Label("Trabajo"), 1,3);
            GPu.add(new Label("Comentario"), 1,4);
            GPu.add(t1 = new TextField(""), 2,0); 
            GPu.add(t2 = new TextField(""), 2,1);
            GPu.add(t3 = new TextField(""), 2,2);
            GPu.add(t4 = new TextField(""), 2,3);
            GPu.add(t5 = new TextField(""), 2,4);
        GPu.setLayoutX(30);GPu.setLayoutY(50);
        Button Guardar = new Button("Guardar");
        Guardar.setMinSize(150, 50);
        Guardar.setLayoutX(210);Guardar.setLayoutY(300);
        retorno.getChildren().addAll(te,GPu,Guardar);
        Guardar.setOnAction((ActionEvent event) -> {
         GuardarD();
        });
        return retorno;
    }
    
   public void GuardarD(){
        aq = new asistentellamada();
        if(t1.getText().equals("")||t2.getText().equals("")||t3.getText().equals("")||t4.getText().equals("")||t5.getText().equals("")){
        Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Error 404");
                alert.setHeaderText("Error");
                alert.setContentText("No puede dejar, datos sin llenar");
                alert.showAndWait();}else{
        Llamada Lc = new Llamada(Integer.parseInt(t1.getText()),Integer.parseInt(t2.getText()),t3.getText(),t4.getText(),t5.getText());
        aq.crearLlamada(Lc,Integer.parseInt(t1.getText()));
        t1.setText("");t2.setText("");t3.setText("");t4.setText("");t5.setText("");
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Llamada");
            alert.setHeaderText(null);
            alert.setContentText("Llamada Almacenada");
            alert.showAndWait();
        
        }
    }
    
   
}
