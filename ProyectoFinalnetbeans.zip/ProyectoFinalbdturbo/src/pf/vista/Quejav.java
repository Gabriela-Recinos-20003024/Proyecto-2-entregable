/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pf.vista;

import static javafx.application.Platform.exit;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import pf.Modelo.Codigo;
import pf.Modelo.Etapa;
import pf.Modelo.Queja;
import pf.Modelo.Rellamada;
import pf.controlador.asistenteetapa;
import pf.controlador.asistentequeja;
import pf.controlador.asistenterellamada;

/**
 *
 * @author tavop
 */
public class Quejav {
    TextField t1,t2,t3,t4,t5;
    asistentequeja aq;
    asistenteetapa cd;
    asistenterellamada ar;
    ChoiceBox cb;
    /*
    this.nqueja = nqueja;
        this.codigo = codigo;
        this.etapa = etapa;
        this.ntelefono = ntelefono;
        this.trabajo = trabajo;
        this.comentario = comentario;
    */
    public Pane crearpanel(){
        Pane retorno = new Pane();
        cd = new asistenteetapa();
        Label te = new Label("Ingreso de quejas");
        te.setLayoutX(30);te.setLayoutY(50);
        GridPane GPu = new GridPane();
         GPu.setPadding(new Insets(10, 10, 10, 10)); 
            GPu.setVgap(20); 
            GPu.setHgap(30);
            GPu.add(new Label("No. Queja"), 1,0); 
            GPu.add(new Label("No. Telefono"), 1,1);
            GPu.add(new Label("Trabajo Realizado"), 1,2);
            GPu.add(new Label("Comentario"), 1,3);
            GPu.add(new Label("Etapa"), 1,4);
            GPu.add(t1 = new TextField(""), 2,0); 
            GPu.add(t2 = new TextField(""), 2,1);
            GPu.add(t3 = new TextField(""), 2,2);
            GPu.add(t4 = new TextField(""), 2,3);
            cb = cd.ListaEtapa();
            cb.setValue("TGE");
            GPu.add(cb, 2,4);
        GPu.setLayoutX(30);GPu.setLayoutY(70);
        Button Guardar = new Button("Guardar");
        Guardar.setMinSize(150, 50);
        Guardar.setLayoutX(210);Guardar.setLayoutY(300);
        retorno.getChildren().addAll(te,GPu,Guardar);
        Guardar.setOnAction((ActionEvent event) -> {
         GuardarD();
        });
        retorno.setLayoutX(10);retorno.setLayoutY(10);
        return retorno;
    }
    
    public void GuardarD(){
        asistenteetapa xy = new asistenteetapa();
        aq = new asistentequeja();
        ar = new asistenterellamada();
        int x = cb.getSelectionModel().getSelectedIndex();
        Codigo cd = new Codigo(0);
        //System.out.println("->"+x);
        Etapa et = new Etapa(x);
        if(t1.getText().equals("")||t2.getText().equals("")||t3.getText().equals("")||t4.getText().equals("")){
        Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Error 404");
                alert.setHeaderText("Error");
                alert.setContentText("No puede dejar datos sin llenar");
                alert.showAndWait();
        }else{
        Queja Qc = new Queja(Integer.parseInt(t1.getText()),cd,et,Integer.parseInt(t2.getText()),t3.getText(),t4.getText());
        Rellamada RL = new Rellamada(100+Integer.parseInt(t1.getText()),cd,Qc,"Pendiente de llamada");
        aq.crearQueja(Qc,Integer.parseInt(t1.getText()));
        ar.crearReLlamada(RL,100+Integer.parseInt(t1.getText()));
        t1.setText("");t2.setText("");t3.setText("");t4.setText("");
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Correcto");
            alert.setHeaderText(null);
            alert.setContentText("Queja almacenada");
            alert.showAndWait();
        }
    }


}
