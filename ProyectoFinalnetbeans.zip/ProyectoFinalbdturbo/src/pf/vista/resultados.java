/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pf.vista;

import java.time.LocalDate;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.chart.BarChart;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import pf.controlador.asistentegrafica;

/**
 *
 * @author tavop
 */
public class resultados {
    
    GridPane x;
    asistentegrafica AG = new asistentegrafica();
    BarChart grafico;
    Pane y, panelgrafico;
    
    
    public DatePicker Search(){
    DatePicker datePicker = new DatePicker();
    datePicker.setOnAction(new EventHandler() {
     public void handle(Event t) {
         LocalDate date = datePicker.getValue();
         grafico = AG.resultados(""+date);
         x.getChildren().clear();
         x.setVgap(20); 
            x.setHgap(10);     
            x.add(new Label("Seleccione una fecha"), 1,0);
            x.add(Search(), 1,1);
            x.add(new Separator(),1,2);
            x.add(grafico,1,3);
     }
    });
    return datePicker;
    }
    
    public Pane panelGrafica(){
    y = new Pane();
    x = new GridPane();
        x.setPadding(new Insets(10, 10, 10, 10)); 
            x.setVgap(20); 
            x.setHgap(10);     
            x.add(new Label("Seleccione una fecha"), 1,0);
            x.add(Search(), 1,1);
            x.add(new Separator(),1,2);

        return x;
    }
}
