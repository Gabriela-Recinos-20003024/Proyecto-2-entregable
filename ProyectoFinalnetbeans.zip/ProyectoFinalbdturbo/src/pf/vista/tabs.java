/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pf.vista;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import pf.controlador.asistentegrafica;

/**
 *
 * @author tavop
 */
public class tabs {
    
    public void tabs(){
    }
    
    public TabPane creartab(){
        Quejav QV = new Quejav();
        Llamadav LV = new Llamadav();
        tablasv TV = new tablasv();
        TabPane TP = new TabPane();
        resumen RS = new resumen();
        resultados RR = new resultados();
        
            Tab tab1 = new Tab("Quejas");
            Tab tab2 = new Tab("Recibidas");
            Tab tab3 = new Tab("Salientes");
            Tab tab4 = new Tab("Grafica");
            Tab tab5 = new Tab("Listado");
            Tab tab6 = new Tab("Resumen");
            tab1.setContent(QV.crearpanel());
            tab2.setContent(LV.crearpanel());
            tab3.setContent(TV.TablaRellamada());
            tab4.setContent(RR.panelGrafica());
            tab5.setContent(TV.listatabla());
            tab6.setContent(RS.resumenx());
            //tab4.setContent(AG.Search());
            //tab.setContent(new Rectangle(200,200, Color.LIGHTSTEELBLUE));
            TP.getTabs().addAll(tab1,tab2,tab3,tab4,tab5,tab6);
            
            TP.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends Tab> ov, Tab t, Tab t1) -> {
                tab3.setContent(TV.TablaRellamada());
                tab5.setContent(TV.listatabla());
                tab6.setContent(RS.resumenx());
        });
            TP.setLayoutX(30);TP.setLayoutY(30);
        return TP;
    }
}
