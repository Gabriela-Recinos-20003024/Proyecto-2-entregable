/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectofinalbdturbo;

import javafx.application.Application;
import static javafx.application.Platform.exit;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import pf.controlador.asistenteusuario;
import pf.vista.tabs;

/**
 *
 * @author tavop
 */
public class ProyectoFinalbdturbo extends Application {

    public Scene ScenePrincipal;
    public Pane PanelInicial;
    public asistenteusuario ausuario;
    public GridPane GPu;
    
    public void PanelInicial(){
    PanelInicial = new Pane();
    ingresoUsuario();
   PanelInicial.getStylesheets().add("css/General.css");
    ScenePrincipal = new Scene(PanelInicial, 600,500);
    }
    
    public void ingresoUsuario(){
        Pane paneu = new Pane();
        TextField usuario = new TextField("");
        PasswordField password = new PasswordField();
        Image imgFTemporal = new Image("pf/Imagenes/logoTT2.png",300,150,false,false);
        ImageView FTemporal = new ImageView(imgFTemporal);
        FTemporal.setLayoutX(160);FTemporal.setLayoutY(40);

        GridPane GPu = new GridPane();
            GPu.setPadding(new Insets(10, 10, 10, 10)); 
            GPu.setVgap(6); 
            GPu.setHgap(6);     
            GPu.add(new Label("Usuario"), 1,0); 
            GPu.add(new Label("Password"), 1,1);
            GPu.add(usuario, 2,0); 
            GPu.add(password, 2,1);
        GPu.setLayoutX(180);GPu.setLayoutY(220);
        Button Ingresar = new Button("Ingresar");
        Ingresar.setLayoutX(210);Ingresar.setLayoutY(310);
        Ingresar.setMinSize(200, 50);
        paneu.getChildren().addAll(GPu,Ingresar);
        Button Salir = new Button("Salir");
        Salir.setLayoutX(540);Salir.setLayoutY(450);
        paneu.getChildren().addAll(FTemporal,Salir);
        PanelInicial.getChildren().add(paneu);
        
        Ingresar.setOnAction((ActionEvent event) -> {
            if(usuario.getText().equals("")||password.getText().equals("")){
                Alert alert = new Alert(AlertType.WARNING);
                alert.setTitle("Error 404");
                alert.setHeaderText("Error");
                alert.setContentText("No puede realizar un login sin \n usuario/contraseña");
                alert.showAndWait();
            }else{
                ausuario = new asistenteusuario();
                if(ausuario.Verificar(usuario.getText(),password.getText()).equals("incorrecto")){
                    Alert alert = new Alert(AlertType.WARNING);
                alert.setTitle("Error 404");
                alert.setHeaderText("Error");
                alert.setContentText("Usuario y/o Contraseña \n incorrecta");
                alert.showAndWait();
                }else{
                    System.out.println("Correcto");
                    PanelInicial.getChildren().remove(paneu);
                    llamartab();
                };
            }
        });
        Salir.setOnAction((ActionEvent event) -> {
         System.exit(0);
        });
    }
    public void llamartab(){
        tabs tb = new tabs();
        Label contes = new Label("Gustavo Pereira 08000114");
        contes.setLayoutX(10);contes.setLayoutY(470);
        Button Salir = new Button("Salir");
        Salir.setLayoutX(540);Salir.setLayoutY(450);
        PanelInicial.getChildren().addAll(contes,Salir);
        PanelInicial.getChildren().add(tb.creartab());
        Salir.setOnAction((ActionEvent event) -> {
         System.exit(0);
        });
    }
    @Override
    public void start(Stage primaryStage) {
        
        PanelInicial();
        primaryStage.setTitle("Proyecto Final");
        primaryStage.setScene(ScenePrincipal);
        primaryStage.initStyle(StageStyle.UNDECORATED);
        primaryStage.show();
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
